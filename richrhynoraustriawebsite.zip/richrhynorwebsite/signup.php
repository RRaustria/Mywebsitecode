<?php 
session_start();

include("connection.php");
include("functions.php");

if($_SERVER['REQUEST_METHOD'] == "POST") 
{
  $user_name = $_POST["user_name"];
  $password = $_POST["password"];

  if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
  {
    $user_id = random_num(20);
    $query = "insert into users (user_id , user_name , password) values ('$user_id'  ,'$user_name' ,'$password')";

    mysqli_query($con ,$query);

    header("Location: login.php");
    die;
  }
  else
   {
    echo "Wrong username and password!";
  }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="this is ph bus ticketing">
  <meta name="author" content="Booc Aloysius">
  <link rel="icon" href="image/buslogo.png" type="image/x-icon">
  <link rel="stylesheet" href="style/login.css" type="text/css">
  <script src="https://kit.fontawesome.com/18c96a2e97.js" crossorigin="anonymous"></script>
  <title>Signup</title>
</head>
<body>
  <main class="background">
    <div class="box">
      <form method="post">
        <h1>Signup </h1>
        <div class="inputs inputs1">
          <label for="user_name">Username:</label>
          <input type="text" name="user_name" id="user_name">
        </div>
        <div class="inputs inputs2">
          <label for="password">Password:</label>
          <input type="password" name="password" id="password">
        </div>
          <button type="submit" value="submit">Signup</button>
          <div class="account">
           <p>Already Have An Account?</p><a href="login.php">Login here!</a>
          </div>
      </form>
    </div>
    
  </main>
</body>
</html>