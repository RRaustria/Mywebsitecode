<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="this is ph bus ticketing">
  <meta name="author" content="Booc Aloysios">
  <link rel="icon" href="image/buslogo.png" type="image/x-icon">
  <link rel="stylesheet" href="style/destination.css" type="text/css">
  <script src="https://kit.fontawesome.com/18c96a2e97.js" crossorigin="anonymous"></script>
  <title>PHBUS DESTINATIONS</title>
</head>
<body>
  <header>
     <section class="header1">
      <img src="image/Capture.PNG" alt="bus-logo" width="200" height="50">
      <nav>
        <ul >
          <li><a href="home.php">HOME</a></li>
          <li><a href="destination.php">DESTINATIONS</a></li>
          <li><a href="#">BUS OPERATORS</a></li>
          <li><a href="#">BUS RENTAL</a></li>
          <li><a href="#">CITY ROUTES</a></li>
        </ul>
        </section>
      </nav>    
   </header>
   <main class="flex">
      <section class="destination">
        <div>
          <h1>Cebu City to Santander</h1>
          <p>2trips (&#8369;1,000 - &#8369;2,000)</p>
        </div>
        <div class="tripdst">
          <input type="text" name="trip1" id="trip1" placeholder="Cebu City">
          <input type="text" name="trip2" id="trip2" placeholder="Satander">
          <div class="date">
              <input type="date" value="February 2022" >
              <p class="oneway">One Way</p>
          </div>
        </div>
      </section>
   </main>
   <section class="main2">
      <nav class="schedule">
        <ul>
          <li class="border"><a href="destination.php">February 14, Wed</a></li>
          <li class="border"><a href="destination.php">February 15, Thu</a></li>
          <li class="border"><a href="destination.php">February 16, Fri</a></li>
          <li class="border"><a href="destination.php">February 17, Sat</a></li>
          <li class="border"><a href="destination.php">February 18, Sun</a></li>
          <li class="border"><a href="destination.php">February 19, Mon</a></li>
        </ul>
      </nav>
      <div class="boxes">
        <h1>Best Options</h1>
        <div class="flex">
          <div><span class="rec">Recommended</span></div>
          <div><span class="rec2">Instant Confirmation</span></div>
        </div>
          <div class="text">
            <p>6:00am Cebu City</p>
            <p>6h bus trip</p>
            <p>12:00pm Santander</p>
          </div>
          <button class="btn2" id="button" onclick="bookClick()"><a href="qr.php">Book Now</a></button>
          <div class="busred"><img src="image/bus.jpg" alt="busred" width="100" ></div>
          
      </div>
      <div class="boxes">
        
        <div class="flex">
          <div><span class="rec">Recommended</span></div>
          <div><span class="rec2">Instant Confirmation</span></div>
        </div>
          <div class="text">
            <p>6:00am Sm Seaside</p>
            <p>6h bus trip</p>
            <p>12:00pm Naga</p>
          </div>
          <button class="btn2" id="button" onclick="bookClick()"><a href="qr.php">Book Now</a></button>
          <div class="busred"><img src="image/bus1.webp" height="70" alt="busred" width="100" ></div>
      </div>
   </section>
   
   <footer>
      <img class="foot" src="image/footer.PNG" alt="footer">
   </footer>
   <script src="js/index.js"></script>
</body>
</html>