<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="this is ph bus ticketing">
    <meta name="author" content="Booc Aloysios">
    <link rel="icon" href="image/buslogo.png" type="image/x-icon">
    <link rel="stylesheet" href="style/qr.css" type="text/css">
    <script src="https://kit.fontawesome.com/18c96a2e97.js" crossorigin="anonymous"></script>
  <title>PHBUS DESTINATIONS</title>
  </head>
  <body>
  <header>
     <section class="header1">
      <img src="image/Capture.PNG" alt="bus-logo" width="200" height="50">
      <nav>
        <ul >
          <li><a href="home.php">HOME</a></li>
          <li><a href="destination.php">DESTINATIONS</a></li>
          <li><a href="#">BUS OPERATORS</a></li>
          <li><a href="#">BUS RENTAL</a></li>
          <li><a href="#">CITY ROUTES</a></li>
        </ul>
        </section>
      </nav>    
   </header>
    <main class="background">
      <div class="box123">
        <button id="btn" onclick="getQR()" class="Generate1">
          Generate QR CODE
        </button>
      </div>
      <img src="th.jpg" alt="" id="qrcode" class="qrcode1" />
    </main>
      <footer>
        <img class="foot" src="image/footer.PNG" alt="footer">
      </footer>
  
    <script src="js/index.js"></script>
  </body>
</html>
