function bookClick() {
  let book = document.getElementById("button");
  alert("Booked Successfull");
}
function getQR() {
  let img = document.getElementById("qrcode");
  img.src = "image/qrcode.PNG";
}
