<?php
session_start();

include("connection.php");
include("functions.php");


$user_data = check_login($con);

?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="this is ph bus ticketing">
  <meta name="author" content="Booc Aloysios">
  <link rel="icon" href="image/buslogo.png" type="image/x-icon">
  <link rel="stylesheet" href="style/style.css" type="text/css">
  <script src="https://kit.fontawesome.com/18c96a2e97.js" crossorigin="anonymous"></script>
  <title>PHBUS HOMEPAGE</title>
  <style>
    .logout  a:hover{
      color: rgb(33, 158, 180);
    }
  </style>
</head>
<body>
  
   <header>
        <div style="background-color:skyblue; height:1.5rem; width:5rem; text-align:center; line-height:1.5rem;  " class="logout"><a style="color:black ; text-decoration:none" href="login.php">Logout</a></div>
     <section class="header1">
      <img src="image/Capture.PNG" alt="bus-logo" width="200" height="50">
      <nav>
        <ul>
          <li><a href="">HOME</a></li>
          <li><a href="destination.php">DESTINATIONS</a></li>
          <li><a href="">BUS OPERATORS</a></li>
          <li><a href="">BUS RENTAL</a></li>
          <li><a href="">CITY ROUTES</a></li>
        </ul>
        </section>
      </nav>    
   </header>
   <main class="routes">
      <section class="main-routes">
          <h1>PHBus Ticketing Phillipines</h1>
          <div class="trip">
            <div class="box">
              <input type="radio" name="trip" id="oneway">
              <label for="oneway">One Way</label>
            </div>
            <div class="box">
              <input type="radio" name="trip" id="roundtrip">
              <label for="roundtrip">Round Trip</label>
            </div>
          </div>
          <div class="dropdown">
            <div class="inline">
              <i class="fa-solid fa-location-dot location"></i>
              <select class="trips1" name="trips" id="trips1">
                <option value="Cebu City">Cebu City</option>
                <option value="Carcar">Sm Seaside</option>
              </select> 
              <button class="swaps">
                <i id="js-swap" class="fa-solid fa-arrow-right-arrow-left swap  " ></i>
              </button>
              <select class="trips2" name="trips" id="trips2">
                <option value="Naga">Naga</option>
                <option value="Satander">Satander</option>
              </select>
                <div class="date-class">
                  <input type="date"  >
                  <p>One Way</p>
                </div>
                <div class="user">
                  <i class="fa-solid fa-user users"></i>
                  <input type="number" id="number">
                </div>    
            </div>
            <div class="submitbtn">
              <button class="btn" type="submit"><a href="destination.php"> Find Tickets</a> </button>
            </div>
          </div>   
      </section>
   </main>
   <footer>
      <img class="foot" src="image/footer.PNG" alt="footer">
   </footer>
</body>
</html>