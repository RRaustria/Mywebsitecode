<?php

session_start();

include("connection.php");
include("functions.php");

if($_SERVER['REQUEST_METHOD'] == "POST") 
{
  $user_name = $_POST["user_name"];
  $password = $_POST["password"];

  if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
  {
    
    $query = "select * from users where user_name = '$user_name' limit 1";

    $result = mysqli_query($con ,$query);

    if($result) 
    {
      if($result && mysqli_num_rows($result) > 0)
    {
      $user_data = mysqli_fetch_assoc($result);
      if($user_data['password'] === $password){

        $_SESSION['user_id'] = $user_data['user_id'];

        header("Location: home.php");
        die;
      }
    }
    }
    echo "Wrong username and password!";
  }
  else
   {
    echo "Wrong username and password!";
  }
}


?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="this is ph bus ticketing">
  <meta name="author" content="Booc Aloysios">
  <link rel="icon" href="image/buslogo.png" type="image/x-icon">
  <link rel="stylesheet" href="style/login.css" type="text/css">
  <script src="https://kit.fontawesome.com/18c96a2e97.js" crossorigin="anonymous"></script>
  <title>Login</title>
</head>
<body>
  <main class="background">
    <div class="box">
      <form method="post">
        <h1>Login </h1>
        <div class="inputs inputs1">
          <label for="username">Username:</label>
          <input type="text" name="user_name" id="user_name">
        </div>
        <div class="inputs inputs2">
          <label for="password">Password:</label>
          <input type="password" name="password" id="password">
        </div>
          <button type="submit" value="submit">Login</button>
          <div class="account">
           <p>Don't Have an Account?</p><a href="signup.php">Signup here!</a>
          </div>
      </form>
    </div>
    
  </main>
</body>
</html>