<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "bus_ticketing";

if(!$con = mysqli_connect($dbhost ,$dbuser, $dbpass ,$dbname ))
 {
  die("Failed to Connected!");
}